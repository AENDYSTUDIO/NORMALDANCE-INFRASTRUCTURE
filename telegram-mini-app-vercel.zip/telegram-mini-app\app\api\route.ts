import { NextResponse } from "next/server";

// Пример API endpoint для Telegram Mini App
export async function GET() {
  return NextResponse.json({ message: "NormalDance Telegram API" });
}
