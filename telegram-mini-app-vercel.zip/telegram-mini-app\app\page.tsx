"use client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useEffect, useState } from "react";

export default function TelegramApp() {
  const [isReady, setIsReady] = useState(false);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const initializeTelegram = () => {
      if (typeof window !== "undefined" && (window as any).Telegram?.WebApp) {
        const tg = (window as any).Telegram.WebApp;
        tg.ready();
        tg.expand();

        // Проверяем наличие метода setHeaderColor
        if (tg.setHeaderColor) {
          tg.setHeaderColor("#6366f1");
        }

        // Проверяем наличие initDataUnsafe
        if (tg.initDataUnsafe?.user) {
          setUser(tg.initDataUnsafe.user);
        }
        setIsReady(true);
      }
    };

    // Инициализируем Telegram WebApp
    initializeTelegram();
  }, []);

  if (!isReady) return <div className="p-4">Loading...</div>;

  const handleOpenLink = () => {
    if (
      typeof window !== "undefined" &&
      (window as any).Telegram?.WebApp?.openLink
    ) {
      (window as any).Telegram.WebApp.openLink("/music");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <Card className="max-w-md mx-auto">
        <CardHeader>
          <CardTitle>NormalDance</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>Welcome, {user?.first_name || "User"}!</p>
          <Button className="w-full" onClick={handleOpenLink}>
            Open Music Platform
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
