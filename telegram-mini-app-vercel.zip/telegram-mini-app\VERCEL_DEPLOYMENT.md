# Deploying to Vercel

## Prerequisites

1. A Vercel account (free at [vercel.com](https://vercel.com))
2. The Telegram Mini App code (this repository)

## Deployment Methods

### Method 1: Deploy from Git Repository (Recommended)

1. Push your code to GitHub, GitLab, or Bitbucket
2. Go to your Vercel dashboard
3. Click "New Project"
4. Import your repository
5. Vercel will automatically detect it's a Next.js project
6. Click "Deploy"

Vercel will automatically:

- Install dependencies
- Build the project
- Deploy to a public URL

### Method 2: Deploy using Vercel CLI

1. Install Vercel CLI globally:

   ```bash
   npm install -g vercel
   ```

2. Navigate to the telegram-mini-app directory:

   ```bash
   cd telegram-mini-app
   ```

3. Deploy to Vercel:

   ```bash
   vercel --prod
   ```

4. Follow the prompts to link to your Vercel account and configure the project

### Method 3: Deploy using ZIP file

1. Create a ZIP file of the telegram-mini-app directory
2. Go to your Vercel dashboard
3. Click "New Project"
4. Select "Other" as the framework
5. Upload the ZIP file
6. Configure the build settings:
   - Build Command: `npm run build`
   - Output Directory: `.next`
   - Install Command: `npm install`

## Environment Variables

No environment variables are required for the basic Telegram Mini App. However, if you extend the app with additional features, you may need to add environment variables in the Vercel dashboard under "Settings" > "Environment Variables".

## Custom Domain

To use a custom domain:

1. In your Vercel dashboard, go to your project
2. Click "Settings" > "Domains"
3. Add your domain
4. Follow the DNS configuration instructions

## Troubleshooting

### Build Failures

If your build fails, check:

1. All dependencies are correctly listed in package.json
2. The build script in package.json is correct
3. There are no TypeScript errors

### Deployment Issues

If deployment fails:

1. Check the build logs in the Vercel dashboard
2. Ensure all required files are included
3. Verify the vercel.json configuration

## Vercel Configuration

This project includes a `vercel.json` file that:

- Configures the build process for Next.js
- Sets security headers for Telegram integration
- Defines environment variables
- Optimizes the deployment

## Post-Deployment

After deployment:

1. Note the URL provided by Vercel
2. Update your Telegram Bot configuration with this URL
3. Test the Mini App in Telegram
