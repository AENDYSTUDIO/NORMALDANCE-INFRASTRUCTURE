import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        background: "var(--tg-bg-color, #ffffff)",
        foreground: "var(--tg-text-color, #000000)",
        primary: {
          DEFAULT: "var(--tg-button-color, #2481cc)",
          foreground: "var(--tg-button-text-color, #ffffff)",
        },
      },
    },
  },
  plugins: [],
};

export default config;
