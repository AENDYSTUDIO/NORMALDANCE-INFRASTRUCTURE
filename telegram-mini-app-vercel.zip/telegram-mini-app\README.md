# NormalDance Telegram Mini App

Это Telegram Mini App для платформы NormalDance - децентрализованной музыкальной платформы.

## Структура проекта

```
telegram-mini-app/
├── app/                 # Основные страницы приложения
│   ├── layout.tsx       # Основной layout приложения
│   └── page.tsx         # Главная страница
├── components/          # Компоненты пользовательского интерфейса
│   ├── telegram-ux-adapter.tsx
│   └── ui/              # Базовые UI компоненты
│       ├── button.tsx
│       └── card.tsx
├── lib/                 # Вспомогательные функции
│   └── utils.ts
├── types/               # Типы TypeScript
│   └── telegram.d.ts
├── .eslintrc.json       # Конфигурация ESLint
├── package.json         # Зависимости проекта
├── tailwind.config.ts   # Конфигурация Tailwind CSS
└── tsconfig.json        # Конфигурация TypeScript
```

## Установка и запуск

1. Установите зависимости:

   ```bash
   npm install
   ```

2. Запустите приложение в режиме разработки:

   ```bash
   npm run dev
   ```

3. Откройте [http://localhost:3000](http://localhost:3000) в браузере.

## Развертывание

Для создания production сборки:

```bash
npm run build
```

Для запуска production сервера:

```bash
npm start
```

### Развертывание на Vercel

Приложение готово для развертывания на Vercel. Подробные инструкции смотрите в файле [VERCEL_DEPLOYMENT.md](VERCEL_DEPLOYMENT.md).

## Интеграция с Telegram

Приложение использует Telegram Web App SDK для интеграции с Telegram. Все необходимые скрипты и стили уже подключены в [layout.tsx](app/layout.tsx).

## Стилизация

Проект использует Tailwind CSS для стилизации компонентов. Тема адаптируется под текущую тему Telegram приложения.
