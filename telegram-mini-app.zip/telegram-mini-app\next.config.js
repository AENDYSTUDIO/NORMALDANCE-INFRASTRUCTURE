/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  experimental: {
    appDir: true,
  },
  // Добавляем заголовки для разрешения использования Telegram Web App SDK
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          {
            key: "Content-Security-Policy",
            value:
              "script-src 'self' 'unsafe-inline' https://telegram.org; object-src 'none';",
          },
        ],
      },
    ];
  },
};

module.exports = nextConfig;
