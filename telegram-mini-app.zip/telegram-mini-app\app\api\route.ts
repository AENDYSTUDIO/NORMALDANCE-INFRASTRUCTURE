// Пример API endpoint для Telegram Mini App
export async function GET() {
  return new Response(JSON.stringify({ message: "NormalDance Telegram API" }), {
    headers: {
      "Content-Type": "application/json",
    },
  });
}
